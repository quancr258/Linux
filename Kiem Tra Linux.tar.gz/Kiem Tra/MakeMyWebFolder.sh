mkdir -p Myweb/images/icon Myweb/images/background Myweb/images/animation Myweb/databases Myweb/scripts Myweb/java
