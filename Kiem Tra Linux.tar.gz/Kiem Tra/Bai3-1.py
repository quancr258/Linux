r = input("Ban kinh: ")
pi = 3.14
cv = 2*r*pi
dt = r*r*pi
print 'chu vi hinh tron ban kinh',r,'la:',cv
print 'dien tich hinh tron ban kinh',r,'la:',dt
